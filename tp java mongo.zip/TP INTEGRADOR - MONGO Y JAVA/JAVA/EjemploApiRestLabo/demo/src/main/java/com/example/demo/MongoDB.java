package com.example.demo;

import com.mongodb.MongoClient;
import com.mongodb.client.*;
import org.bson.Document;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
class MongoDB {
    private MongoDatabase baseDeDatos;
    private MongoCollection coleccion;

    public MongoDB(){
        this.conectar("inventario","producto");
    }

    public MongoDB(String coleccion) {
        this.conectar("inventario",coleccion);
    }

    public void conectar(String baseDeDatos,String coleccion){
        this.conectarABaseDeDatos(baseDeDatos);
        this.conectarAColeccion(coleccion);
    }

    public MongoDatabase getBaseDeDatos() {
        return baseDeDatos;
    }

    public void setBaseDeDatos(MongoDatabase baseDeDatos) {
        this.baseDeDatos = baseDeDatos;
    }

    public MongoCollection getColeccion() {
        return coleccion;
    }

    public void setColeccion(MongoCollection coleccion) {
        this.coleccion = coleccion;
    }

    public void conectarABaseDeDatos(String nombreBaseDeDatos){
        MongoClient mongo = new MongoClient("localhost",27017);
        this.baseDeDatos = mongo.getDatabase(nombreBaseDeDatos);
    }

    public void conectarAColeccion(String nombreDeColeccion){
        if (this.existeLaColeccion(nombreDeColeccion)){
            this.coleccion = baseDeDatos.getCollection(nombreDeColeccion);
        } else {
            baseDeDatos.createCollection(nombreDeColeccion);
            this.coleccion = baseDeDatos.getCollection(nombreDeColeccion);
        }
    }

    public boolean existeLaColeccion(String nombreDeColeccion){

        MongoIterable<String> nombresDeColecciones = baseDeDatos.listCollectionNames();
        boolean existe = false;

        for (String nombre : nombresDeColecciones) {
            if (nombre.equals(nombreDeColeccion)){
                existe = true;
            }
        }
        return existe;
    }

    public HashMap<String,Object> obtenerDatosProducto(){
        HashMap<String,Object> datos = new HashMap<>();
        ArrayList<Producto> productos = new ArrayList<>();

        FindIterable resultado = coleccion.find();
        MongoCursor iterador = resultado.iterator();

        while (iterador.hasNext()) {
            Document documento = (Document) iterador.next();
            String nombre = documento.getString("nombre");
            String desc = documento.getString("descripcion");
            String categoria = documento.getString("categoria");
            double precioCompra = documento.getDouble("precioCompra");
            double precioVenta = documento.getDouble("precioVenta");
            int stock = documento.getInteger("stock");
            int stockMinimo = documento.getInteger("stockReposicion");
            String nombreProveedor = documento.getString("nombreProveedor");

            Producto producto = new Producto(nombre,desc,categoria,precioCompra,precioVenta,stock,stockMinimo,nombreProveedor);

            productos.add(producto);

            System.out.println(nombre + " - " + desc);
        }

        datos.put("alumnos",productos);
        return datos;
    }

    public int obtenerProducto(HashMap<String,Object> filtros /** opcional **/) {
        //Producto alumno = new Producto();
        /** aquí se deben tomar los valores del map para armar el json (opcional) **/
        String json = "{ nombre : { $eq : \"Nadia\" } }";
        Document filtro = Document.parse(json);
        FindIterable resultado = coleccion.find(filtro);
        MongoCursor iterador = resultado.iterator();

        while (iterador.hasNext()){
            Document documento = (Document) iterador.next();
            String nombre = documento.getString("nombre");
            int edad = documento.getInteger("edad");
            System.out.println(nombre + " - " + edad);
        }

        return 0;
    }

    public void insertarProducto(Producto producto){
        Document nuevoDocumento = new Document();
        nuevoDocumento.append("nombre",producto.getNombre());
        nuevoDocumento.append("descripcion",producto.getDescripcion());
        nuevoDocumento.append("categoria",producto.getCategoria());
        nuevoDocumento.append("precioCompra",producto.getPrecioCompra());
        nuevoDocumento.append("precioVenta",producto.getPrecioVenta());
        nuevoDocumento.append("stock",producto.getStock());
        nuevoDocumento.append("stockReposicion",producto.getStockMinimo());
        nuevoDocumento.append("nombreProveedor",producto.getNombreProveedor());

        coleccion.insertOne(nuevoDocumento);
    }

    public void insertarAlumnos(List<Producto> alumnos){

        List<Document> documentosAInsertar = new ArrayList<>();

        for (Producto alumno : alumnos) {

            Document nuevoDocumento = new Document();
            //nuevoDocumento.append("nombre",alumno.getNombre());
            //nuevoDocumento.append("edad",alumno.getEdad());
            documentosAInsertar.add(nuevoDocumento);

        }

        coleccion.insertMany(documentosAInsertar);
    }

    public void actualizarDatosDeVariosAlumnos(/** parámetros? **/){
        String json = "{ edad: { $eq : 23 } }";
        Document filtro = Document.parse(json);
        json = "{ $set: { edad :  25 } }";
        Document nuevosValores= Document.parse(json);
        coleccion.updateOne(filtro,nuevosValores);
    }

    public void eliminarAlumno(int id){
        String json = "{ nombre: { $eq: \"Nadia\" } }";
        Document filtro = Document.parse(json);
        coleccion.deleteOne(filtro);
    }

    public void eliminarVariosAlumnos(/** ¿parámetros? **/){
        String json = "{ edad : { $eq: 25 } }";
        Document filtro = Document.parse(json);
        coleccion.deleteMany(filtro);
    }

    public static void main(String[] args) {
        MongoDB mongo = new MongoDB("producto");
        mongo.obtenerDatosProducto();
    }
    /**
     * documentación de clase Document
     * http://mongodb.github.io/mongo-java-driver/3.6/javadoc/org/bson/Document.html
     */

}
