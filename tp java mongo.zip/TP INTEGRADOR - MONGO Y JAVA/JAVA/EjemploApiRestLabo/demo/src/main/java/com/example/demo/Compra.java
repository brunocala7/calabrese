package com.example.demo;

import java.util.HashMap;

public class Compra {
    private HashMap<String,Object> producto;
    private Proveedor proveedor;
    private float precioTotal;

    public Compra(HashMap<String, Object> producto, Proveedor proveedor, float precioTotal) {
        this.producto = producto;
        this.proveedor = proveedor;
        this.precioTotal = precioTotal;
    }

    public HashMap<String, Object> getProducto() {
        return producto;
    }

    public void setProducto(HashMap<String, Object> producto) {
        this.producto = producto;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    public float getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(float precioTotal) {
        this.precioTotal = precioTotal;
    }
}
