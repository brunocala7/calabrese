package com.example.demo;

import java.util.HashMap;
import java.util.HashSet;

public class Proveedor {
    private String nombre;
    private HashMap<String, String> ubicacion;
    private int contacto;
    private HashSet<HashMap<String,Integer>> listaProductos;

    public Proveedor(String nombre, HashMap<String, String> ubicacion, int contacto, HashSet<HashMap<String, Integer>> listaProductos) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.contacto = contacto;
        this.listaProductos = listaProductos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public HashMap<String, String> getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(HashMap<String, String> ubicacion) {
        this.ubicacion = ubicacion;
    }

    public int getContacto() {
        return contacto;
    }

    public void setContacto(int contacto) {
        this.contacto = contacto;
    }

    public HashSet<HashMap<String, Integer>> getListaProductos() {
        return listaProductos;
    }

    public void setListaProductos(HashSet<HashMap<String, Integer>> listaProductos) {
        this.listaProductos = listaProductos;
    }
}

