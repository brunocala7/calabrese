package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

/** url: http://localhost:8080/api/... **/

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class Controller {

    @Autowired
    private MongoDB accesoABaseDeDatos;

    public Controller() {
        this.accesoABaseDeDatos = new MongoDB();
    }

    @RequestMapping(value = "/datos/producto", method = RequestMethod.GET)
    public ResponseEntity<Object> obtenerProductos() {
        HashMap<String, Object> datos = accesoABaseDeDatos.obtenerDatosProducto();
        return new ResponseEntity<>(datos, HttpStatus.OK);
    }

    @RequestMapping(value = "/datos/alumnos", method = RequestMethod.POST)
    public ResponseEntity<Object> agregarProducto(@RequestBody HashMap producto) {
        String nombre = (String) producto.get("nombre");
        int edad = (int) pro.get("edad");
        return new ResponseEntity<>(HttpStatus.OK);
    }

}

